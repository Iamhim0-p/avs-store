# Ademmy Varieties Store (AVS)

This is the first deployable AVS storefront prototype.

## Deploy on Vercel
1. Create a GitHub repository named `avs-store`.
2. Upload `index.html` to the repository root and commit it.
3. In Vercel, choose **Add New → Project**.
4. Import the `avs-store` GitHub repository.
5. For a plain HTML site, leave the framework preset as **Other** and leave build/output settings empty.
6. Click **Deploy**.

## Important prototype limitation
The product manager currently stores products in the browser's local storage. Products added on one device/browser do not sync to other customers or devices. This first deployment is suitable for previewing the storefront, not yet for operating a shared live shop.

Before taking real customer orders, connect a shared database (for products and orders), add secure admin access, and configure payment processing. Never put payment secret keys in browser code.
